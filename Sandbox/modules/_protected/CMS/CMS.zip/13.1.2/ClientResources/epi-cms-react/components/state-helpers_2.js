define(["require","exports"],(function(o,t){"use strict";function e(){return window.state?.get("contentState")}function n(){return window.state?.get("projectState")}function r(){return window.state?.get("visitorGroupState")}t.getContentState=e,t.getProjectState=n,t.getVisitorGroupState=r}));
//# sourceMappingURL=state-helpers_2.js.map
