define("epi-cms/command/TranslateContentToSpecificLanguage", [
    "dojo/_base/declare",
    "./TranslateContent"
], function (declare, TranslateContent) {
    return declare([TranslateContent], {
        // summary:
        //      Command used to translate content to the language specified in the normalized model as targetLanguage.
        //      The command will be disable if the current user doesn't have permission to translate to that language.
        _onModelChange: function () {
            // summary:
            //      Updates canExecute after the model has been updated.
            // tags:
            //      protected
            this._normalizeModel(this.model).then(function (normalizedModel) {
                this.model = normalizedModel;
                var isAvailable = this.calculateIsAvailable(normalizedModel);
                this.set("isAvailable", isAvailable);
                if (normalizedModel && normalizedModel.missingLanguages && normalizedModel.missingLanguages.length > 0) {
                    var canExecute = this.calculateCanExecute(normalizedModel);
                    var missingLanguageIds = normalizedModel.missingLanguages.map(function (lang) {
                        return lang.languageId;
                    });
                    var canTranslateTargetLanguage = !!(normalizedModel.targetLanguage && missingLanguageIds.indexOf(normalizedModel.targetLanguage) > -1);
                    this.set("canExecute", canExecute && canTranslateTargetLanguage);
                }
                else {
                    this.set("canExecute", false);
                }
            }.bind(this));
        }
    });
});
